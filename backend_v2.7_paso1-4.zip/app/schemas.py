"""
schemas.py
----------
Estas clases NO son las tablas de la base de datos (eso está en models.py).
Son los "formularios" que definen exactamente qué forma tiene que tener la
información que entra a cada endpoint (request) y qué forma tiene la que sale
(response). FastAPI las usa para validar automáticamente: si el frontend manda
algo mal formado, FastAPI responde con un error 422 claro, sin que tengamos
que escribir ese chequeo a mano.
"""

from datetime import date, datetime
from datetime import date as date_type  # alias para no pisar el campo "date" dentro de las clases
from datetime import time as dt_time
from typing import List, Literal, Optional
from uuid import UUID

import re

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


# ---------- Hijos (children) ----------

# Foto de perfil (issue #36). La app la reduce a ~256 px y la manda como texto
# ("data URI") dentro del mismo pedido que crea/edita al hijo: no hay subida aparte
# ni almacenamiento nuevo. Tope de 150.000 caracteres (~110 KB de imagen): la foto
# real pesa ~15-30 KB, así que sobra margen y la base no se llena de archivos grandes.
AVATAR_MAX_CARACTERES = 150_000
_AVATAR_PATRON = re.compile(r"^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$")


def _validar_avatar(valor: Optional[str]) -> Optional[str]:
    if valor is None:
        return None
    if len(valor) > AVATAR_MAX_CARACTERES:
        raise ValueError("La foto es demasiado pesada.")
    if not _AVATAR_PATRON.match(valor):
        raise ValueError("La foto debe ser una imagen JPEG, PNG o WEBP en base64.")
    return valor


class ChildCreate(BaseModel):
    name: str
    birth_date: Optional[date] = None
    avatar_url: Optional[str] = None

    @field_validator("avatar_url")
    @classmethod
    def _avatar_valido(cls, v):
        return _validar_avatar(v)


class ChildUpdate(BaseModel):
    """
    Cuerpo de PUT /children/{child_id} (editar un hijo).
    Se manda SOLO lo que cambia; lo que no se manda, queda como estaba.
      - name: no puede ser vacío ni null.
      - birth_date: "AAAA-MM-DD" para fijarla; null para borrarla.
      - avatar_url: foto como data URI (ver ChildCreate); null para quitarla.
    Un cuerpo vacío ({}) se rechaza con 422.
    Compatible con la app actual, que manda solo { name }.
    """
    name: Optional[str] = None
    birth_date: Optional[date] = None
    avatar_url: Optional[str] = None

    @field_validator("avatar_url")
    @classmethod
    def _avatar_valido(cls, v):
        return _validar_avatar(v)

    @model_validator(mode="after")
    def _validar_cambios(self):
        enviados = self.model_fields_set
        if not enviados:
            raise ValueError("Mandá al menos un campo para cambiar (name, birth_date o avatar_url).")
        if "name" in enviados and (self.name is None or not self.name.strip()):
            raise ValueError("El nombre no puede estar vacío.")
        return self


class ChildOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)  # permite construirlo desde el modelo de SQLAlchemy

    id: int
    name: str
    birth_date: Optional[date] = None
    avatar_url: Optional[str] = None


class ChildrenResponse(BaseModel):
    children: List[ChildOut]


class ChildResponse(BaseModel):
    child: ChildOut


# ---------- Documentos ----------

class UploadResponse(BaseModel):
    status: str
    expiry_date: Optional[date] = None
    no_expiry: bool = False
    drive_link: Optional[str] = None
    doc_id: int
    folder_id: Optional[int] = None
    mime_type: Optional[str] = None


class DocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    expiry_date: Optional[date] = None
    no_expiry: bool = False
    status: str
    drive_link: Optional[str] = None
    folder_id: Optional[int] = None
    mime_type: Optional[str] = None  # None = todavía no se sabe (documento anterior a v2.4)


class DocumentUpdate(BaseModel):
    """
    Cuerpo de PATCH /documents/{doc_id}. Se manda SOLO lo que cambia, con al
    menos una de estas cosas:
      { "name": "DNI de Lola" }         -> cambia el nombre (no puede ser vacío)
      { "expiry_date": "2027-03-15" }   -> fija la fecha (no_expiry pasa a false)
      { "no_expiry": true }             -> el documento no vence (expiry_date pasa a NULL)
    El nombre se puede combinar con una de las dos formas de vencimiento.
    Se rechazan con 422: cuerpo vacío, expiry_date y no_expiry=true juntos,
    no_expiry=false, y un nombre vacío o null.
    """
    name: Optional[str] = None
    expiry_date: Optional[date] = None
    no_expiry: Optional[bool] = None
    # Carpeta destino: un número para mover; null para dejarlo suelto (raíz "Docukids").
    folder_id: Optional[int] = None

    @model_validator(mode="after")
    def _validar(self):
        if "name" in self.model_fields_set:
            nombre = (self.name or "").strip()
            if not nombre:
                raise ValueError("El nombre no puede estar vacío.")
            self.name = nombre
        if self.no_expiry is False:
            raise ValueError("no_expiry solo puede ser true; para fijar una fecha mandá expiry_date.")
        if self.no_expiry is True and self.expiry_date is not None:
            raise ValueError("Mandá expiry_date o no_expiry=true, no las dos a la vez.")
        if (
            self.name is None
            and self.expiry_date is None
            and self.no_expiry is None
            and "folder_id" not in self.model_fields_set
        ):
            raise ValueError("Mandá al menos un campo: name, expiry_date, no_expiry=true o folder_id.")
        return self


# ---------- Carpetas (folders) ----------

_MAX_NOMBRE_CARPETA = 30


def _limpiar_nombre_carpeta(valor: Optional[str]) -> str:
    nombre = (valor or "").strip()
    if not nombre:
        raise ValueError("El nombre de la carpeta no puede estar vacío.")
    if len(nombre) > _MAX_NOMBRE_CARPETA:
        raise ValueError(f"El nombre de la carpeta puede tener hasta {_MAX_NOMBRE_CARPETA} letras.")
    return nombre


class FolderCreate(BaseModel):
    name: str

    @model_validator(mode="after")
    def _validar(self):
        self.name = _limpiar_nombre_carpeta(self.name)
        return self


class FolderUpdate(BaseModel):
    """Cuerpo de PATCH /folders/{id}: solo se puede cambiar el nombre (obligatorio)."""
    name: str

    @model_validator(mode="after")
    def _validar(self):
        self.name = _limpiar_nombre_carpeta(self.name)
        return self


class FolderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    is_base: bool = False


class FolderResponse(BaseModel):
    folder: FolderOut


class FoldersResponse(BaseModel):
    folders: List[FolderOut]


class DocumentsResponse(BaseModel):
    documents: List[DocumentOut]


class DeleteResponse(BaseModel):
    message: str


class TrashedDocumentOut(BaseModel):
    """Un documento que la persona borró y todavía se puede restaurar desde la papelera de Drive."""
    drive_file_id: str
    name: str
    type: Optional[str] = None
    child_id: int
    child_name: str
    folder_id: Optional[int] = None
    expiry_date: Optional[date] = None
    no_expiry: bool = False
    mime_type: Optional[str] = None
    days_left: int  # días que le quedan en la papelera de Drive (máx. 30)


class TrashedDocumentsResponse(BaseModel):
    documents: List[TrashedDocumentOut]


class RestoreDocumentResponse(BaseModel):
    doc_id: int
    child_id: int
    name: str


class MigrateResponse(BaseModel):
    """
    Respuesta de POST /drive/migrate (Drive por hijo, v2.6). Se vuelve a llamar
    hasta que remaining sea 0.
      - migrated:  archivos que quedaron en su carpeta de hijo y con su nombre nuevo.
      - skipped:   archivos que ya no existen en Drive (o están en la papelera); el
                   documento NO se borra, solo se da por revisado.
      - remaining: documentos que todavía faltan.
    """
    migrated: int
    skipped: int
    remaining: int


# ---------- Recuperar datos tras re-registro (v2.8) ----------

class RecoverMatch(BaseModel):
    """Un hijo que la persona YA tiene con el mismo nombre que la carpeta vieja."""
    child_id: int
    name: str
    # True: ese hijo todavía no tiene carpeta propia en Drive, así que la carpeta vieja se
    # vincula a él (no se crea un hijo repetido). False: ya tiene archivos propios en Drive;
    # para no mezclar ni pisar nada, la carpeta vieja se recupera como un perfil aparte.
    can_link: bool


class RecoverCandidate(BaseModel):
    """Una carpeta de hijo que quedó en Drive y todavía no está vinculada a ningún hijo."""
    drive_folder_id: str
    name: str
    old_child_id: int
    documents: int
    folders: List[str]
    match: Optional[RecoverMatch] = None


class RecoverPreviewResponse(BaseModel):
    candidates: List[RecoverCandidate]


class RecoverRequest(BaseModel):
    # Solo se reciben ids de carpetas; los archivos se vuelven a leer de Drive en el servidor.
    folders: List[str] = Field(min_length=1, max_length=20)


class RecoverResponse(BaseModel):
    """
    - recovered: hijos recuperados (con su carpeta vieja ya vinculada, sin duplicar).
    - linked:    cuántos de ellos ya existían (se vinculó la carpeta vieja a su perfil).
    - documents: documentos reconectados.
    - skipped:   ids pedidos que ya no existen o ya estaban vinculados (no es error).
    - remaining: documentos por renombrar; llamar a POST /drive/migrate hasta que sea 0.
    """
    recovered: List[ChildOut]
    documents: int
    skipped: int
    remaining: int
    # Cuántos de `recovered` son hijos que ya existían y recibieron su carpeta vieja.
    linked: int = 0


# ---------- Turnos (appointments) ----------

# Lugar del turno (v2.7): nombre, dirección y coordenadas, todo opcional.
LUGAR_TEXTO_MAX = 300


def _limpiar_texto_lugar(valor: Optional[str]) -> Optional[str]:
    if valor is None:
        return None
    valor = valor.strip()
    if len(valor) > LUGAR_TEXTO_MAX:
        raise ValueError(f"El texto del lugar es demasiado largo (máximo {LUGAR_TEXTO_MAX} caracteres).")
    return valor or None


def _validar_coordenadas(latitude: Optional[float], longitude: Optional[float]) -> None:
    if (latitude is None) != (longitude is None):
        raise ValueError("Mandá latitud y longitud juntas, o ninguna de las dos.")
    if latitude is not None:
        if not -90 <= latitude <= 90:
            raise ValueError("La latitud tiene que estar entre -90 y 90.")
        if not -180 <= longitude <= 180:
            raise ValueError("La longitud tiene que estar entre -180 y 180.")


class AppointmentCreate(BaseModel):
    child_id: int
    title: str
    date: date
    time: Optional[dt_time] = None
    notes: Optional[str] = None
    location_name: Optional[str] = None
    address: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None

    @field_validator("location_name", "address")
    @classmethod
    def _texto_lugar(cls, v):
        return _limpiar_texto_lugar(v)

    @model_validator(mode="after")
    def _validar_lugar(self):
        _validar_coordenadas(self.latitude, self.longitude)
        return self


class AppointmentCreatedResponse(BaseModel):
    ok: bool
    calendar_event_id: str


class AppointmentUpdate(BaseModel):
    """
    Cuerpo de PATCH /appointments/{appointment_id} (editar un turno).
    Se manda SOLO lo que cambia; lo que no se manda, queda como estaba.
      - title: no puede ser vacío ni null.
      - date: no puede ser null.
      - time: "HH:MM" para fijar hora; null para quitarla (el evento pasa a ser de todo el día).
      - notes: texto, o null / "" para borrarlas.
      - location_name, address, latitude, longitude (v2.7): el lugar del turno.
        Latitud y longitud se mandan juntas. Para QUITAR el lugar se mandan los
        cuatro en null.
    Un cuerpo vacío ({}) se rechaza con 422.
    """
    title: Optional[str] = None
    date: Optional[date_type] = None
    time: Optional[dt_time] = None
    notes: Optional[str] = None
    location_name: Optional[str] = None
    address: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None

    @field_validator("location_name", "address")
    @classmethod
    def _texto_lugar(cls, v):
        return _limpiar_texto_lugar(v)

    @model_validator(mode="after")
    def _validar_cambios(self):
        enviados = self.model_fields_set
        if not enviados:
            raise ValueError("Mandá al menos un campo para cambiar (title, date, time, notes o el lugar).")
        if "title" in enviados and (self.title is None or not self.title.strip()):
            raise ValueError("El título no puede estar vacío.")
        if "date" in enviados and self.date is None:
            raise ValueError("La fecha no puede ser null.")
        # Lugar: las coordenadas se mandan siempre las dos, o ninguna.
        if ("latitude" in enviados) != ("longitude" in enviados):
            raise ValueError("Mandá latitud y longitud juntas, o ninguna de las dos.")
        _validar_coordenadas(self.latitude, self.longitude)
        return self


class AppointmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    date: date
    time: Optional[dt_time] = None
    notes: Optional[str] = None
    calendar_event_id: Optional[str] = None
    location_name: Optional[str] = None
    address: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None


class AppointmentsResponse(BaseModel):
    appointments: List[AppointmentOut]


# ---------- Familia (v2.5) ----------
# OJO: ninguna de estas clases tiene un campo para google_refresh_token.
# Es a propósito: nada de /family puede devolverlo (Guía §12, regla 9).

class FamilyMemberOut(BaseModel):
    id: UUID
    email: str
    role: Literal["owner", "member"]


class FamilyOut(BaseModel):
    id: int
    role: Literal["owner", "member"]  # el rol de QUIEN pregunta
    members: List[FamilyMemberOut]
    # Solo los ve el titular y solo mientras la invitación está vigente.
    invite_code: Optional[str] = None
    invite_expires_at: Optional[datetime] = None  # ISO 8601 en UTC (termina en +00:00)


class FamilyJoin(BaseModel):
    """Cuerpo de POST /family/join."""
    code: str


class FamilyResponse(BaseModel):
    family: Optional[FamilyOut] = None  # null = la persona no tiene familia


class InviteResponse(BaseModel):
    invite_code: str
    invite_expires_at: datetime  # ISO 8601 en UTC (termina en +00:00)
