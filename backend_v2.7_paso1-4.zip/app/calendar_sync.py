"""
calendar_sync.py
-----------------
Fase 2, paso 4 de la Guía Técnica: conecta POST/GET /appointments con
Google Calendar real, usando el mismo google_refresh_token que ya se guardó
en google_oauth.py.

Contrato exacto (Guía Técnica, sección 4):
  POST /appointments {child_id, title, date, time, notes?} -> {ok, calendar_event_id}
  GET  /appointments/{child_id} -> {appointments: [...]}

Nota: la Guía Técnica NO define un DELETE /appointments como endpoint propio,
pero sí hace falta borrar eventos de Calendar cuando se elimina un hijo
completo (ver /children/{child_id} en main.py) -- para eso está
borrar_evento() acá abajo, agregada a pedido explícito del usuario.

--- Refactor hecho ---
La construcción de credenciales OAuth vivía duplicada en drive_upload.py,
calendar_sync.py y notifier.py. Ahora vive en app/google_client.py en la
función build_google_credentials(user, error_context). Los tres módulos la
importan; si hay que tocar la lógica de renovación, se toca en un solo lugar.
"""

from datetime import date as date_type
from datetime import datetime, time as time_type, timedelta
from typing import Optional
import logging

from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

from .config import settings
from .google_client import build_google_credentials, traducir_permisos_de_google
from .models import User

logger = logging.getLogger(__name__)

# --- Variable NUEVA (no está en la Guía Técnica) ---
# Zona horaria para calcular los eventos. La Guía no la especifica; uso
# Argentina porque los ejemplos del proyecto mencionan Buenos Aires
# (Guía Técnica, sección de Google Cloud Console). Cambiala en el .env si
# el proyecto es para otro país.
TIMEZONE = settings.appointment_timezone

# --- Decisión NUEVA (no está en la Guía Técnica) ---
# El contrato de /appointments no pide una hora de fin, solo date+time. Un
# turno médico típico dura media hora; se puede ajustar acá si hace falta.
DURACION_TURNO_MINUTOS = 30


def texto_de_lugar(nombre: Optional[str], direccion: Optional[str]) -> Optional[str]:
    """
    Texto que va en el campo "ubicación" del evento de Google Calendar (v2.7):
    "Nombre, dirección". Si la dirección ya empieza con el nombre, no se repite.
    Devuelve None si no hay ninguno de los dos.
    """
    nombre = (nombre or "").strip()
    direccion = (direccion or "").strip()
    if nombre and direccion:
        if direccion.lower().startswith(nombre.lower()):
            return direccion
        return f"{nombre}, {direccion}"
    return nombre or direccion or None


def _armar_cuerpo_evento(
    title: str,
    fecha: date_type,
    hora: Optional[time_type],
    notes: Optional[str],
    location: Optional[str] = None,
) -> dict:
    """
    Si viene una hora, creamos un evento con horario (dateTime + timeZone).
    Si NO viene hora, lo creamos como evento "de todo el día" (date, sin
    horario) -- es lo que hace Google Calendar nativamente cuando un evento
    no tiene hora puntual.
    """
    if hora is not None:
        inicio = datetime.combine(fecha, hora)
        fin = inicio + timedelta(minutes=DURACION_TURNO_MINUTOS)
        cuerpo = {
            "summary": title,
            "description": notes or "",
            "start": {"dateTime": inicio.isoformat(), "timeZone": TIMEZONE},
            "end": {"dateTime": fin.isoformat(), "timeZone": TIMEZONE},
        }
    else:
        cuerpo = {
            "summary": title,
            "description": notes or "",
            "start": {"date": fecha.isoformat()},
            "end": {"date": fecha.isoformat()},
        }
    # events().update reemplaza el evento entero: si no hay lugar, el campo se
    # omite y Google lo borra, que es justo lo que se quiere al quitar el lugar.
    if location:
        cuerpo["location"] = location
    return cuerpo


@traducir_permisos_de_google("Google Calendar")
def crear_evento(
    user: User,
    title: str,
    fecha: date_type,
    hora: Optional[time_type],
    notes: Optional[str],
    location: Optional[str] = None,
) -> str:
    """
    Crea el evento en el Google Calendar del usuario (calendario "primary",
    el principal). Devuelve el calendar_event_id para guardarlo en la base.
    """
    credenciales = build_google_credentials(user, "Google Calendar")
    servicio = build("calendar", "v3", credentials=credenciales)

    cuerpo_evento = _armar_cuerpo_evento(title, fecha, hora, notes, location)

    evento_creado = (
        servicio.events()
        .insert(calendarId="primary", body=cuerpo_evento)
        .execute()
    )
    return evento_creado["id"]


@traducir_permisos_de_google("Google Calendar")
def actualizar_evento(
    user: User,
    calendar_event_id: Optional[str],
    title: str,
    fecha: date_type,
    hora: Optional[time_type],
    notes: Optional[str],
    location: Optional[str] = None,
) -> str:
    """
    Actualiza el evento en Google Calendar con los valores FINALES del turno y
    devuelve el calendar_event_id (el mismo, o uno nuevo).

    Si el evento ya no existe en Google (404/410: por ejemplo se borró a mano
    desde el teléfono), o el turno no tenía evento guardado, se crea uno nuevo
    en vez de dar error. Otros errores se loguean y se propagan, para no dar por
    guardado un cambio que Google no recibió.

    Usa events().update (reemplaza el evento entero), que es lo que permite pasar
    de "con hora" a "todo el día" y viceversa. Contra: si la persona agregó a mano
    en Google datos que la app no maneja (invitados, recordatorios), se pierden al
    editar el turno desde la app.
    """
    credenciales = build_google_credentials(user, "Google Calendar")
    servicio = build("calendar", "v3", credentials=credenciales)
    cuerpo_evento = _armar_cuerpo_evento(title, fecha, hora, notes, location)

    if calendar_event_id:
        try:
            evento = (
                servicio.events()
                .update(calendarId="primary", eventId=calendar_event_id, body=cuerpo_evento)
                .execute()
            )
            if evento.get("status") != "cancelled":
                return evento["id"]
            logger.info("El evento %s estaba cancelado en Calendar; se crea uno nuevo.", calendar_event_id)
        except HttpError as error:
            status = getattr(error.resp, "status", None)
            if status not in (404, 410):
                logger.warning("Error al actualizar evento %s en Calendar (HTTP %s): %s", calendar_event_id, status, error)
                raise
            logger.info("El evento %s ya no existe en Calendar; se crea uno nuevo.", calendar_event_id)

    evento_nuevo = servicio.events().insert(calendarId="primary", body=cuerpo_evento).execute()
    return evento_nuevo["id"]


@traducir_permisos_de_google("Google Calendar")
def borrar_evento(user: User, calendar_event_id: str) -> None:
    """
    Borra el evento del Google Calendar del usuario (calendario "primary").
    Si el evento ya no existe (ej. el usuario lo borró a mano desde su
    teléfono), Calendar devuelve 404 o 410 (Gone): en ese caso lo ignoramos,
    igual que hace delete_file_from_drive con Drive. Otros errores se loguean
    y se propagan para no dar por borrado algo que en realidad falló.
    """
    credenciales = build_google_credentials(user, "Google Calendar")
    servicio = build("calendar", "v3", credentials=credenciales)

    try:
        servicio.events().delete(calendarId="primary", eventId=calendar_event_id).execute()
    except HttpError as error:
        status = getattr(error.resp, "status", None)
        if status in (404, 410):
            logger.info(
                "Evento %s ya no existe en Calendar o no tenemos acceso; nada que borrar.",
                calendar_event_id,
            )
            return

        logger.warning("Error al borrar evento %s en Calendar (HTTP %s): %s", calendar_event_id, status, error)
        raise
    except Exception as e:
        logger.exception("Error inesperado al borrar evento %s en Calendar: %s", calendar_event_id, e)
        raise
